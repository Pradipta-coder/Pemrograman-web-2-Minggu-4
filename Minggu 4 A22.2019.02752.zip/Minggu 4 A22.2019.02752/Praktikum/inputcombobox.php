<html>
<head><title>Film Kartun Favorit ~ Inputan Combo
box</title></head>
<body>
	<FORM ACTION="prosescombobox.php" METHOD="POST"
NAME="input">
		<h2>Pilih Film Kartun Favorit Anda :</h2>
		<select name="kartun">
		<option value="Sponge Bob">Sponge Bob</option>
		<option value="Sinchan">Sinchan</option>
		<option value="Conan">Conan</option>
		<option value="Doraemon">Doraemon</option>
		<option value="Dragon Ball">Dragon Ball</option>
		<option value="Naruto">Naruto</option>
		</select>
		<input type="submit" name="Pilih" value="Pilih">
	</FORM>
</body>
</html>